package iducs.springboot.bootjpa.service;

import org.springframework.stereotype.Service;

@Service
public class ReplyServiceImpl implements ReplyService {
}
