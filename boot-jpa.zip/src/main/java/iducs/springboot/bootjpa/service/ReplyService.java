package iducs.springboot.bootjpa.service;

public interface ReplyService {
}
