package iducs.springboot.bootjpa.config;

public class WebConfig {
}
