package iducs.springboot.bootjpa.domain;

public class Reply {
}
